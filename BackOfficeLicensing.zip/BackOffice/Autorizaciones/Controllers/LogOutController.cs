﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Autorizaciones.Controllers
{
    public class LogOutController : Controller
    {
        // GET: LogOut      

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index()
        {
            Session.Abandon();
            return RedirectToAction("Login", "Home");           
            //return Json(new { status = "done" });            
            //return JavaScript("window.close();");
           
        }
    }
}