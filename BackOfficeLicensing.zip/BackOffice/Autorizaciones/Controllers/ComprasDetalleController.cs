﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Autorizaciones.Models;
using Autorizaciones.Models.Back;
using PagedList;
using System.Data.Entity.Infrastructure;


namespace Autorizaciones.Controllers
{
    [SessionExpire]
    public class ComprasDetalleController : BaseController
    {
        // GET: ComprasDetalle
        public ActionResult ReqComprasDet(int id,int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);
            try
            {
                var modelordenes = db.C001COMRQG.Where(x => x.No_Req == id).FirstOrDefault();

                ViewBag.lblNoOrden = modelordenes.No_Req;
                ViewBag.lblDepartamento = modelordenes.C001INVDEP.Desc_Esp;
                ViewBag.lblTipo = modelordenes.C001COMTIP.DescTip_Esp;
                ViewBag.lblFecha = modelordenes.Fecha_Req.ToString("yyyy-MM-dd");
                ViewBag.lblComentarios = modelordenes.Notas_Req;
                ViewBag.lblPrioridad = modelordenes.C001COMPRI.Desc_Esp;
            }
            catch (Exception ex)
            {
                return new HttpStatusCodeResult(HttpStatusCode.NotFound);
                throw;
            }
                       

            var viewModel = db.C001COMRQL.Where(x => x.No_Req == id).ToList();
            LoadSessionObject();
            int pageSize = 1000;
            int pageNumber = (page ?? 1);
            return View(viewModel.ToPagedList(pageNumber, pageSize));
        }


        [HttpPost]
        public ActionResult ReqComprasDet(List<C001COMRQL> orden, int? page)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            string ordenesAprobadas = "";
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {
                    foreach (var i in orden)
                    {
                        var ordqupd = db.C001COMRQL.Where(x => x.No_Req == i.No_Req && x.No_Lin == i.No_Lin).FirstOrDefault();
                        if (ordqupd != null)
                        {
                            if (ordqupd.Cantidad != i.Cantidad)
                            {
                                ordqupd.Cantidad = i.Cantidad;
                                ordenesAprobadas = ordenesAprobadas + " " + i.No_Lin.ToString ();
                            }
                        }


                    }
                    if (ModelState.IsValid)
                    {
                        db.SaveChanges();
                    }
                    else
                    {
                        Danger("Por favor ingrese un número válido");
                        return RedirectToAction("ReqComprasDet");

                    }
                }
                if (ordenesAprobadas != "")
                {
                    ViewBag.Message = "Lineas actualizadas.";
                    String mensajeStr = "Se actualizaron las lineas: <b>" + ordenesAprobadas + "</b> por el usuario: <b>{0}</b> ";
                    Success(string.Format(mensajeStr, userAut), true);
                }
                return RedirectToAction("ReqComprasDet");
            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqComprasDet");
                throw;
            }
        }

        public ActionResult Delete(int id, int lin)
        {
            return View();
        }

        // POST: Ordenes/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, int lin, FormCollection collection)
        {
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            string userAut = System.Web.HttpContext.Current.Session["usuario"] as String;
            try
            {
                using (ModelBack db = new ModelBack(connectionStringName))
                {
                    var viewModel2 = db.C001COMCOTI.Where(x => x.No_Requisicion == id && x.No_Linea == lin);
                    foreach (var item in viewModel2.ToList())
                    {
                        db.C001COMCOTI.Remove(item);
                    }
                    db.SaveChanges();

                    var viewModel = db.C001COMRQL.Where(x => x.No_Req == id && x.No_Lin == lin).FirstOrDefault();
                    db.C001COMRQL.Remove(viewModel);
                    db.SaveChanges();
                }

                ViewBag.Message = "Linea borrada.";
                String mensajeStr = "Se borro la linea: <b>" + lin.ToString() + "</b> por el usuario: <b>{0}</b>";
                Success(string.Format(mensajeStr, userAut), true);
                return RedirectToAction("ReqComprasDet");

            }
            catch (Exception ex)
            {
                Danger("Parece que algo salió mal. Por favor revisa tu formulario." + ex.Message.ToString());
                return RedirectToAction("ReqComprasDet");
                throw;
            }

        }

        private void LoadSessionObject()
        {
            // Load session from HttpContext.
            string connectionStringName = System.Web.HttpContext.Current.Session["sessionString"] as String;
            ModelBack db = new ModelBack(connectionStringName);

            var reqAlm = db.C001INVGEN.Where(x => x.Stat_Aut == false && x.Tipo_Mov == "SAL").Count();
            var reqCom = db.C001COMRQG.Where(x => x.Status_Req == false
                                               && x.Cod_Dep != ""
                                               && x.Cod_Prio != "").Count();
            var reqPed = db.C001COMPDG.Where(x => x.Autoriza == false || x.Autoriza2 == false).Count();

            ViewData["reqAlm"] = reqAlm.ToString();
            ViewData["reqCom"] = reqCom.ToString();
            ViewData["reqPed"] = reqPed.ToString();
            ViewData["nombreUsuario"] = System.Web.HttpContext.Current.Session["nombreUsuario"] as String;
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutReq"].ToString()) == true)
            {
                // solo requisiciones
                ViewData["AutReq"] = "True";
            }
            else
            { ViewData["AutReq"] = "False"; }
            if (Convert.ToBoolean(System.Web.HttpContext.Current.Session["AutPed"].ToString()) == true)
            {
                // requisiciones y  pedidos
                ViewData["AutPed"] = "True";
            }
            else
            { ViewData["AutPed"] = "False"; }
        }
    }
}