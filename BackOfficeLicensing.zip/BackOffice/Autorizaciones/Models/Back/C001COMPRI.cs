namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001COMPRI")]
    public partial class C001COMPRI
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public C001COMPRI()
        {
            C001COMRQG = new HashSet<C001COMRQG>();
        }

        [Key]
        [StringLength(1)]
        public string Tip_Prio { get; set; }

        [Required]
        [StringLength(30)]
        public string Desc_Esp { get; set; }

        [StringLength(30)]
        public string Desc_Ing { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<C001COMRQG> C001COMRQG { get; set; }
    }
}
