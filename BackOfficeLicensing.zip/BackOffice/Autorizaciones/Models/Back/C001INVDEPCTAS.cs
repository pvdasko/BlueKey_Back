namespace Autorizaciones.Models.Back
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("001INVDEPCTAS")]
    public partial class C001INVDEPCTAS
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(4)]
        public string Cod_Dep { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(4)]
        public string Cod_Alma { get; set; }

        [Key]
        [Column(Order = 2)]
        [StringLength(4)]
        public string Cod_Sub { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_1 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_2 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_3 { get; set; }

        [Required]
        [StringLength(4)]
        public string Cuenta_4 { get; set; }

        public bool Depto { get; set; }

        public bool Subalma { get; set; }

        public bool Cuenta { get; set; }

        public virtual C001CONCTA C001CONCTA { get; set; }

        public virtual C001INVDEP C001INVDEP { get; set; }

        public virtual C001INVSUB C001INVSUB { get; set; }
    }
}
