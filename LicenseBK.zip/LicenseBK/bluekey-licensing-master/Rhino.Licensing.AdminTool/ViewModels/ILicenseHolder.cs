﻿using Bluekey.Licensing.AdminTool.Model;

namespace Bluekey.Licensing.AdminTool.ViewModels
{
    public interface ILicenseHolder
    {
        License CurrentLicense { get; set; } 
    }
}