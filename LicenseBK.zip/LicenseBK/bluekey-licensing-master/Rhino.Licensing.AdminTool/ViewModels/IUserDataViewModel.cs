﻿using Caliburn.PresentationFramework.Screens;

namespace Bluekey.Licensing.AdminTool.ViewModels
{
    public interface IUserDataViewModel : ILicenseHolder, IScreen
    {
    }
}