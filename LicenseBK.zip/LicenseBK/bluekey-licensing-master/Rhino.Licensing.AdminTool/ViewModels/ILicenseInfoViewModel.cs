﻿using Caliburn.PresentationFramework.Screens;

namespace Bluekey.Licensing.AdminTool.ViewModels
{
    public interface ILicenseInfoViewModel : ILicenseHolder, IScreen
    {
    }
}