﻿namespace Bluekey.Licensing.AdminTool.Views
{
    public interface IAboutView
    {
    }

    /// <summary>
    /// Interaction logic for AboutView.xaml
    /// </summary>
    public partial class AboutView : IAboutView
    {
        public AboutView()
        {
            InitializeComponent();
        }
    }
}
