﻿namespace Bluekey.Licensing.AdminTool.Views
{
    public interface IShellView
    {
    }

    /// <summary>
    /// Interaction logic for ShellView.xaml
    /// </summary>
    public partial class ShellView : IShellView
    {
        public ShellView()
        {
            InitializeComponent();
        }
    }
}
