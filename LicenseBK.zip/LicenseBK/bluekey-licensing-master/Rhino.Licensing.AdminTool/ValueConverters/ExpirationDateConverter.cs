using System;
using System.Globalization;
using System.Windows.Data;

namespace Bluekey.Licensing.AdminTool.ValueConverters
{
    public class ExpirationDateConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
                return "Never";

            if(value is DateTime)
            {
                return ((DateTime)value).ToString("g", culture ?? CultureInfo.InvariantCulture);
            }

            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}