using Bluekey.Licensing.AdminTool.Dialogs;
using Bluekey.Licensing.AdminTool.ViewModels;

namespace Bluekey.Licensing.AdminTool.Factories
{
    public interface IDialogFactory
    {
        /// <summary>
        /// Creates a new FileDialog
        /// </summary>
        /// <typeparam name="T">dialog Type</typeparam>
        /// <typeparam name="TViewModel">viewModel</typeparam>
        /// <returns></returns>
        T Create<T, TViewModel>(TViewModel viewModel)
            where T : FileDialog<TViewModel>
            where TViewModel : IFileDialogViewModel;

        /// <summary>
        /// Releases file dialog for garbage collection
        /// </summary>
        /// <param name="dialog"></param>
        void Release(object dialog);
    }
}