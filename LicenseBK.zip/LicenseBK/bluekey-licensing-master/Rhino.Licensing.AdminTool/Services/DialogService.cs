using Bluekey.Licensing.AdminTool.Factories;
using Bluekey.Licensing.AdminTool.ViewModels;
using OpenFileDialog = Bluekey.Licensing.AdminTool.Dialogs.OpenFileDialog;
using SaveFileDialog = Bluekey.Licensing.AdminTool.Dialogs.SaveFileDialog;

namespace Bluekey.Licensing.AdminTool.Services
{
    public class DialogService : IDialogService
    {
        private readonly IDialogFactory _dialogFactory;

        public DialogService(IDialogFactory dialogFactory)
        {
            _dialogFactory = dialogFactory;
        }

        public virtual void ShowOpenFileDialog(IOpenFileDialogViewModel model)
        {
            var dialog = _dialogFactory.Create<OpenFileDialog, IOpenFileDialogViewModel>(model);

            dialog.ViewModel = model;
            dialog.ShowDialog();

            _dialogFactory.Release(dialog);
        }

        public virtual void ShowSaveFileDialog(ISaveFileDialogViewModel model)
        {
            var dialog = _dialogFactory.Create<SaveFileDialog, ISaveFileDialogViewModel>(model);

            dialog.ViewModel = model;
            dialog.ShowDialog();

            _dialogFactory.Release(dialog);
        }

    }
}