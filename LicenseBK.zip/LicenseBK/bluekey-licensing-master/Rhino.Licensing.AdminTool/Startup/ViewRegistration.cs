using Castle.MicroKernel;
using Castle.MicroKernel.Registration;
using Bluekey.Licensing.AdminTool.Extensions;
using Bluekey.Licensing.AdminTool.Views;

namespace Bluekey.Licensing.AdminTool.Startup
{
    public class ViewRegistration : IRegistration
    {
        public virtual void Register(IKernel kernel)
        {
            kernel.Register(AllTypes.FromAssemblyContaining<ViewRegistration>()
                                    .Where(t => t.Namespace == "Bluekey.Licensing.AdminTool.Views")
                                    .WithService.FirstInterfaceOnClass()
                                    .Configure(c => c.LifeStyle.Transient)
                                    .ConfigureFor<ShellView>(c => c.LifeStyle.Singleton));
        }
    }
}