using System;
using System.Runtime.Serialization;

namespace Bluekey.Licensing
{
    /// <summary>
    /// Base class for all licensing exceptions.
    /// </summary>
    [Serializable]
    public class BluekeyLicensingException : Exception
    {
        /// <summary>
        /// Creates a new instance of <seealso cref="BluekeyLicensingException"/>.
        /// </summary>
        protected BluekeyLicensingException()
        {
        }

        /// <summary>
        /// Creates a new instance of <seealso cref="BluekeyLicensingException"/>.
        /// </summary>
        /// <param name="message">error message</param>
        protected BluekeyLicensingException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Creates a new instance of <seealso cref="BluekeyLicensingException"/>.
        /// </summary>
        /// <param name="message">error message</param>
        /// <param name="inner">inner exception</param>
        protected BluekeyLicensingException(string message, Exception inner)
            : base(message, inner)
        {
        }

        /// <summary>
        /// Creates a new instance of <seealso cref="BluekeyLicensingException"/>.
        /// </summary>
        /// <param name="info">serialization information</param>
        /// <param name="context">streaming context</param>
        protected BluekeyLicensingException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }
    }
}