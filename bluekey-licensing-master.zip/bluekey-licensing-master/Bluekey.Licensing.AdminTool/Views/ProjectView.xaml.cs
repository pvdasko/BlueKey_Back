﻿namespace Bluekey.Licensing.AdminTool.Views
{
    public interface IProjectView
    {
    }

    /// <summary>
    /// Interaction logic for ProjectView.xaml
    /// </summary>
    public partial class ProjectView : IProjectView
    {
        public ProjectView()
        {
            InitializeComponent();
        }
    }
}
