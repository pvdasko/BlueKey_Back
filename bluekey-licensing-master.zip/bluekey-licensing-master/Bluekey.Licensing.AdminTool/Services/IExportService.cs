using System.IO;
using Bluekey.Licensing.AdminTool.Model;

namespace Bluekey.Licensing.AdminTool.Services
{
    public interface IExportService
    {
        /// <summary>
        /// Exports a license as xml format
        /// </summary>
        /// <param name="product"></param>
        /// <param name="license"></param>
        /// <param name="path"></param>
        void Export(Product product, License license, FileInfo path);
    }
}