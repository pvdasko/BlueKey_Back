﻿using Caliburn.PresentationFramework.Screens;
using Bluekey.Licensing.AdminTool.Model;

namespace Bluekey.Licensing.AdminTool.ViewModels
{
    public class LicenseInfoViewModel : Screen, ILicenseInfoViewModel
    {
        private License _currentLicense;

        public virtual License CurrentLicense
        {
            get { return _currentLicense; }
            set
            {
                _currentLicense = value;
                NotifyOfPropertyChange(() => CurrentLicense);
            }
        }
    }
}