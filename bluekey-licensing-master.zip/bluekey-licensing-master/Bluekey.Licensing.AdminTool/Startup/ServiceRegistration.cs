using Castle.MicroKernel;
using Castle.MicroKernel.Registration;
using Bluekey.Licensing.AdminTool.Extensions;

namespace Bluekey.Licensing.AdminTool.Startup
{
    public class ServiceRegistration : IRegistration
    {
        public virtual void Register(IKernel kernel)
        {
            kernel.Register(AllTypes.FromAssemblyContaining<ServiceRegistration>()
                                    .Where(t => t.Namespace == "Bluekey.Licensing.AdminTool.Services")
                                    .WithService.FirstInterfaceOnClass()
                                    .Configure(c => c.LifeStyle.Transient));
        }
    }
}