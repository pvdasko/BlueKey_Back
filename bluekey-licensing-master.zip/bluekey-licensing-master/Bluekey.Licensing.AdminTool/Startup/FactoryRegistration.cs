using Castle.MicroKernel;
using Castle.MicroKernel.Registration;
using Bluekey.Licensing.AdminTool.Extensions;
using Bluekey.Licensing.AdminTool.Factories;
using Castle.Facilities.TypedFactory;

namespace Bluekey.Licensing.AdminTool.Startup
{
    public class FactoryRegistration : IRegistration
    {
        public virtual void Register(IKernel kernel)
        {
            kernel.AddFacility<TypedFactoryFacility>();

            kernel.Register(Component.For<IViewModelFactory>().AsFactory());

            kernel.Register(Component.For<IDialogFactory>().AsFactory());

            kernel.Register(AllTypes.FromAssemblyContaining<ViewModelRegistration>()
                                    .Where(t => t.Namespace == "Bluekey.Licensing.AdminTool.Factories")
                                    .WithService.FirstInterfaceOnClass());
        }
    }
}