﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bluekey.Licensing.Prueba
{
    class Program
    {
        static void Main(string[] args)
        {
            var publicKey = File.ReadAllText("publicKey.xml");

            new LicenseValidator(publicKey, "license.xml")
              .AssertValidLicense();

            Console.WriteLine("Hello");
            Console.ReadKey();
        }
    }
}
