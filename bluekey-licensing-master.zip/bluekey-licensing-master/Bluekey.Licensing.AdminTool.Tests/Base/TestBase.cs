namespace Bluekey.Licensing.AdminTool.Tests.Base
{
    public class TestBase
    {
        static TestBase()
        {
            //seem to hang when upgraded to PSAKE 4.0
            //var app = new App();
            //app.InitializeComponent();
        }
    }
}